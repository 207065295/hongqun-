#ifndef _IWDG_H
#define _IWDG_H

void IWDG_Init(unsigned char pre,unsigned int rlr);
void IWDG_FeedDog(void);

#endif
